--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.5
-- Dumped by pg_dump version 16.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE sellnegrs;
--
-- Name: sellnegrs; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE sellnegrs WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Russian_Russia.1251';


ALTER DATABASE sellnegrs OWNER TO postgres;

\connect sellnegrs

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: sellnegr; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sellnegr (
    negr_id bigint NOT NULL,
    negr_name character varying NOT NULL,
    negr_post character varying,
    negr_history text,
    negr_price integer NOT NULL
);


ALTER TABLE public.sellnegr OWNER TO postgres;

--
-- Name: sellnegr_negr_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sellnegr_negr_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sellnegr_negr_id_seq OWNER TO postgres;

--
-- Name: sellnegr_negr_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sellnegr_negr_id_seq OWNED BY public.sellnegr.negr_id;


--
-- Name: sellnegr negr_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sellnegr ALTER COLUMN negr_id SET DEFAULT nextval('public.sellnegr_negr_id_seq'::regclass);


--
-- Data for Name: sellnegr; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sellnegr (negr_id, negr_name, negr_post, negr_history, negr_price) FROM stdin;
\.
COPY public.sellnegr (negr_id, negr_name, negr_post, negr_history, negr_price) FROM '$$PATH$$/4781.dat';

--
-- Name: sellnegr_negr_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sellnegr_negr_id_seq', 7, true);


--
-- Name: sellnegr sellnegr_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sellnegr
    ADD CONSTRAINT sellnegr_pk PRIMARY KEY (negr_id);


--
-- PostgreSQL database dump complete
--

