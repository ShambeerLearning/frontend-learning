--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.5
-- Dumped by pg_dump version 16.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE lesson3;
--
-- Name: lesson3; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE lesson3 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Russian_Russia.1251';


ALTER DATABASE lesson3 OWNER TO postgres;

\connect lesson3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: client; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.client (
    client_id bigint NOT NULL,
    client_name character varying NOT NULL,
    client_number character varying NOT NULL,
    client_email character varying NOT NULL
);


ALTER TABLE public.client OWNER TO postgres;

--
-- Name: client_client_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.client_client_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.client_client_id_seq OWNER TO postgres;

--
-- Name: client_client_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.client_client_id_seq OWNED BY public.client.client_id;


--
-- Name: negrs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.negrs (
    negrs_id bigint NOT NULL,
    negrs_name character varying NOT NULL,
    negrs_post character varying NOT NULL,
    negrs_history character varying,
    negrs_age character varying NOT NULL
);


ALTER TABLE public.negrs OWNER TO postgres;

--
-- Name: negrs_negrs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.negrs_negrs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.negrs_negrs_id_seq OWNER TO postgres;

--
-- Name: negrs_negrs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.negrs_negrs_id_seq OWNED BY public.negrs.negrs_id;


--
-- Name: purchases; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.purchases (
    purchases_id bigint NOT NULL,
    purchases_client bigint NOT NULL,
    purchases_negr bigint NOT NULL,
    purchases_price character varying NOT NULL
);


ALTER TABLE public.purchases OWNER TO postgres;

--
-- Name: purchases_purchases_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.purchases_purchases_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.purchases_purchases_id_seq OWNER TO postgres;

--
-- Name: purchases_purchases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.purchases_purchases_id_seq OWNED BY public.purchases.purchases_id;


--
-- Name: client client_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client ALTER COLUMN client_id SET DEFAULT nextval('public.client_client_id_seq'::regclass);


--
-- Name: negrs negrs_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.negrs ALTER COLUMN negrs_id SET DEFAULT nextval('public.negrs_negrs_id_seq'::regclass);


--
-- Name: purchases purchases_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchases ALTER COLUMN purchases_id SET DEFAULT nextval('public.purchases_purchases_id_seq'::regclass);


--
-- Data for Name: client; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/4801.dat

--
-- Data for Name: negrs; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/4799.dat

--
-- Data for Name: purchases; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/4803.dat

--
-- Name: client_client_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.client_client_id_seq', 1, false);


--
-- Name: negrs_negrs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.negrs_negrs_id_seq', 1, false);


--
-- Name: purchases_purchases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.purchases_purchases_id_seq', 1, false);


--
-- Name: client client_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT client_pk PRIMARY KEY (client_id);


--
-- Name: negrs negrs_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.negrs
    ADD CONSTRAINT negrs_pk PRIMARY KEY (negrs_id);


--
-- Name: purchases purchases_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT purchases_pk PRIMARY KEY (purchases_id);


--
-- Name: purchases purchases_client_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT purchases_client_fk FOREIGN KEY (purchases_client) REFERENCES public.client(client_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: purchases purchases_negrs_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT purchases_negrs_fk FOREIGN KEY (purchases_negr) REFERENCES public.negrs(negrs_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

